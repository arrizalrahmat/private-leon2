# Lampiran

1. Gambar pada folder `menu` dipindahkan ke project frontend (React)

2. Gunnakan Fake server dengan menggunakan JSON Server dari `db.json`

Jalankan command line berikut pada terminalmu 

> npx json-server db.json --port 3001